//package com.example.demo.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.demo.Models.Login;
//import com.example.demo.repository.LoginRepo;
//@RestController
//
//public class LoginController {
//	@Autowired
//	LoginRepo repository;
//
//	@GetMapping("/getvalues")
//	List<Login>getList(){
//		return repository.findAll();
//	}
//}
