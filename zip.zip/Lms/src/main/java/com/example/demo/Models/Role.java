package com.example.demo.Models;

public enum Role {
    USER,
    ADMIN
}
